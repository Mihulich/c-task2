#include "dictionary.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>

Dictionary::Dictionary() : logger(Logger::getInstance()) {
    logger.log(LogLevel::INFO, "Dictionary initialized");
}

void Dictionary::addWord(const std::string& word, const std::vector<std::string>& translations) {
    if (word.empty()) {
        logger.log(LogLevel::ERROR, "Attempted to add empty word");
        throw std::invalid_argument("Word cannot be empty");
    }
    
    words[word] = translations;
    logger.log(LogLevel::INFO, "Added word: " + word + " with " + 
               std::to_string(translations.size()) + " translation(s)");
}

std::vector<std::string> Dictionary::getTranslations(const std::string& word) const {
    auto it = words.find(word);
    if (it == words.end()) {
        logger.log(LogLevel::WARNING, "Word not found: " + word);
        return std::vector<std::string>();
    }
    return it->second;
}

void Dictionary::loadFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        logger.log(LogLevel::ERROR, "Failed to open file: " + filename);
        throw std::runtime_error("Could not open file: " + filename);
    }

    clear();
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string word;
        if (std::getline(iss, word, ':')) {
            std::vector<std::string> translations;
            std::string translation;
            while (std::getline(iss, translation, ',')) {
                if (!translation.empty()) {
                    // Trim whitespace
                    translation.erase(0, translation.find_first_not_of(" \t"));
                    translation.erase(translation.find_last_not_of(" \t") + 1);
                    translations.push_back(translation);
                }
            }
            addWord(word, translations);
        }
    }
    
    logger.log(LogLevel::INFO, "Loaded dictionary from file: " + filename);
}

void Dictionary::saveToFile(const std::string& filename) const {
    std::ofstream file(filename);
    if (!file.is_open()) {
        logger.log(LogLevel::ERROR, "Failed to save to file: " + filename);
        throw std::runtime_error("Could not open file for writing: " + filename);
    }

    for (const auto& [word, translations] : words) {
        file << word << ":";
        for (size_t i = 0; i < translations.size(); ++i) {
            file << translations[i];
            if (i < translations.size() - 1) {
                file << ",";
            }
        }
        file << "\n";
    }
    
    logger.log(LogLevel::INFO, "Saved dictionary to file: " + filename);
}

bool Dictionary::hasWord(const std::string& word) const {
    return words.find(word) != words.end();
}

std::vector<std::string> Dictionary::getAllWords() const {
    std::vector<std::string> result;
    result.reserve(words.size());
    for (const auto& [word, _] : words) {
        result.push_back(word);
    }
    return result;
}

void Dictionary::removeWord(const std::string& word) {
    auto it = words.find(word);
    if (it != words.end()) {
        words.erase(it);
        logger.log(LogLevel::INFO, "Removed word: " + word);
    } else {
        logger.log(LogLevel::WARNING, "Attempted to remove non-existent word: " + word);
    }
}

void Dictionary::clear() {
    words.clear();
    logger.log(LogLevel::INFO, "Dictionary cleared");
} 