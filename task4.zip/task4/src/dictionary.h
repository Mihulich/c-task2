#pragma once

#include <string>
#include <map>
#include <vector>
#include <memory>
#include <stdexcept>
#include "logger.h"

class Dictionary {
public:
    Dictionary();
    
    void addWord(const std::string& word, const std::vector<std::string>& translations);
    
    std::vector<std::string> getTranslations(const std::string& word) const;
    
    void loadFromFile(const std::string& filename);
    
    void saveToFile(const std::string& filename) const;
    
    bool hasWord(const std::string& word) const;
    
    std::vector<std::string> getAllWords() const;
    
    void removeWord(const std::string& word);
    
    void clear();

private:
    std::map<std::string, std::vector<std::string>> words;
    Logger& logger;
}; 