#pragma once

#include <fstream>
#include <string>
#include <mutex>
#include <chrono>

enum class LogLevel {
    INFO,
    WARNING,
    ERROR
};

class Logger {
public:
    static Logger& getInstance();
    void log(LogLevel level, const std::string& message);
    
private:
    Logger();
    ~Logger();
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    std::ofstream logFile;
    std::mutex logMutex;
    const std::string getTimestamp();
    const std::string getLevelString(LogLevel level);
}; 