#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFileDialog>
#include <QMessageBox>
#include <QStringList>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), dictionary(std::make_unique<Dictionary>())
{
    setupUi();
}

MainWindow::~MainWindow() = default;

void MainWindow::setupUi() {
    auto* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    
    auto* mainLayout = new QVBoxLayout(centralWidget);
    
    searchBox = new QLineEdit(this);
    searchBox->setPlaceholderText("Search words...");
    mainLayout->addWidget(searchBox);
    
    wordList = new QListWidget(this);
    mainLayout->addWidget(wordList);
    
    auto* wordLayout = new QHBoxLayout();
    wordInput = new QLineEdit(this);
    wordInput->setPlaceholderText("Enter word");
    wordLayout->addWidget(wordInput);
    
    translationsInput = new QTextEdit(this);
    translationsInput->setPlaceholderText("Enter translations (one per line)");
    translationsInput->setMaximumHeight(100);
    mainLayout->addLayout(wordLayout);
    mainLayout->addWidget(translationsInput);
    
    auto* buttonLayout = new QHBoxLayout();
    addButton = new QPushButton("Add Word", this);
    removeButton = new QPushButton("Remove Word", this);
    loadButton = new QPushButton("Load Dictionary", this);
    saveButton = new QPushButton("Save Dictionary", this);
    
    buttonLayout->addWidget(addButton);
    buttonLayout->addWidget(removeButton);
    buttonLayout->addWidget(loadButton);
    buttonLayout->addWidget(saveButton);
    mainLayout->addLayout(buttonLayout);
    
    statusLabel = new QLabel(this);
    mainLayout->addWidget(statusLabel);
    
    connect(searchBox, &QLineEdit::textChanged, this, &MainWindow::onSearchTextChanged);
    connect(wordList, &QListWidget::itemClicked, this, &MainWindow::onWordSelected);
    connect(addButton, &QPushButton::clicked, this, &MainWindow::onAddWord);
    connect(removeButton, &QPushButton::clicked, this, &MainWindow::onRemoveWord);
    connect(loadButton, &QPushButton::clicked, this, &MainWindow::onLoadDictionary);
    connect(saveButton, &QPushButton::clicked, this, &MainWindow::onSaveDictionary);
    
    setWindowTitle("Dictionary Application");
    resize(600, 400);
}

void MainWindow::onAddWord() {
    QString word = wordInput->text().trimmed();
    if (word.isEmpty()) {
        showError("Word cannot be empty");
        return;
    }
    
    QStringList translations = translationsInput->toPlainText().split('\n', Qt::SkipEmptyParts);
    std::vector<std::string> translationVec;
    for (const QString& trans : translations) {
        QString trimmed = trans.trimmed();
        if (!trimmed.isEmpty()) {
            translationVec.push_back(trimmed.toStdString());
        }
    }
    
    try {
        dictionary->addWord(word.toStdString(), translationVec);
        wordInput->clear();
        translationsInput->clear();
        updateWordList();
        showInfo("Word added successfully");
    } catch (const std::exception& e) {
        showError(e.what());
    }
}

void MainWindow::onRemoveWord() {
    auto* item = wordList->currentItem();
    if (!item) {
        showError("Please select a word to remove");
        return;
    }
    
    QString word = item->text();
    dictionary->removeWord(word.toStdString());
    updateWordList();
    showInfo("Word removed successfully");
}

void MainWindow::onLoadDictionary() {
    QString filename = QFileDialog::getOpenFileName(this, "Load Dictionary", "", "Dictionary Files (*.dict);;All Files (*)");
    if (filename.isEmpty()) return;
    
    try {
        dictionary->loadFromFile(filename.toStdString());
        updateWordList();
        showInfo("Dictionary loaded successfully");
    } catch (const std::exception& e) {
        showError(e.what());
    }
}

void MainWindow::onSaveDictionary() {
    QString filename = QFileDialog::getSaveFileName(this, "Save Dictionary", "", "Dictionary Files (*.dict);;All Files (*)");
    if (filename.isEmpty()) return;
    
    try {
        dictionary->saveToFile(filename.toStdString());
        showInfo("Dictionary saved successfully");
    } catch (const std::exception& e) {
        showError(e.what());
    }
}

void MainWindow::onWordSelected(QListWidgetItem* item) {
    if (!item) return;
    
    QString word = item->text();
    auto translations = dictionary->getTranslations(word.toStdString());
    
    wordInput->setText(word);
    QString translationsText;
    for (const auto& trans : translations) {
        if (!translationsText.isEmpty()) translationsText += '\n';
        translationsText += QString::fromStdString(trans);
    }
    translationsInput->setText(translationsText);
}

void MainWindow::onSearchTextChanged(const QString& text) {
    wordList->clear();
    auto allWords = dictionary->getAllWords();
    QString searchLower = text.toLower();
    
    for (const auto& word : allWords) {
        QString qword = QString::fromStdString(word);
        if (text.isEmpty() || qword.toLower().contains(searchLower)) {
            wordList->addItem(qword);
        }
    }
}

void MainWindow::updateWordList() {
    QString searchText = searchBox->text();
    onSearchTextChanged(searchText);
}

void MainWindow::showError(const QString& message) {
    statusLabel->setText("Error: " + message);
    statusLabel->setStyleSheet("color: red");
}

void MainWindow::showInfo(const QString& message) {
    statusLabel->setText(message);
    statusLabel->setStyleSheet("color: green");
} 