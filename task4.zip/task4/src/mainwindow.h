#pragma once

#include <QMainWindow>
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QLabel>
#include <memory>
#include "dictionary.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onAddWord();
    void onRemoveWord();
    void onLoadDictionary();
    void onSaveDictionary();
    void onWordSelected(QListWidgetItem* item);
    void onSearchTextChanged(const QString& text);

private:
    void setupUi();
    void updateWordList();
    void showError(const QString& message);
    void showInfo(const QString& message);

    std::unique_ptr<Dictionary> dictionary;
    QListWidget* wordList;
    QLineEdit* searchBox;
    QLineEdit* wordInput;
    QTextEdit* translationsInput;
    QPushButton* addButton;
    QPushButton* removeButton;
    QPushButton* loadButton;
    QPushButton* saveButton;
    QLabel* statusLabel;
}; 